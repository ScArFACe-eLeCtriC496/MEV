================================================================================
  ChainForge — Execução no Windows (nota do desenvolvedor)
================================================================================

Por que o Windows mostra um aviso (SmartScreen)
--------------------------------------------------------------------------------
O programa não está assinado com um certificado pago de editor. O Windows trata
o ficheiro como “desconhecido”, por isso pode aparecer a janela azul
“O Windows protegeu o seu PC” ou “Não foi possível verificar o editor”. Isso é
NORMAL em compilações sem assinatura e não significa automaticamente vírus.

Não há código malicioso nesta compilação — é uma aplicação de ambiente de
trabalho normal (Tauri). Se confia na origem do ficheiro, pode executá-la.

Como executar SEM desativar totalmente a proteção do Windows
--------------------------------------------------------------------------------
1) Faça duplo clique em app.exe.

2) Se o SmartScreen aparecer:
   • Clique em “Mais informações” (More info).
   • Depois em “Executar mesmo assim” (Run anyway).

Assim só permite ESTE ficheiro; não desativa a proteção de todo o sistema.

Extra (se o ficheiro estiver “bloqueado” após o download)
--------------------------------------------------------------------------------
1) Botão direito no exe → Propriedades.
2) Em baixo, se existir “Desbloquear”, marque a caixa → OK.

Não recomendado
--------------------------------------------------------------------------------
Desativar permanentemente o SmartScreen ou o Windows Defender enfraquece a
segurança do PC. Basta autorizar uma vez este programa, como acima.

O que precisa no computador
--------------------------------------------------------------------------------
• Windows 10 ou 11 (64 bits).
• O WebView2 costuma já estar instalado; se der erro ao iniciar, instale o
  “Microsoft Edge WebView2 Runtime” no site oficial da Microsoft.

================================================================================
