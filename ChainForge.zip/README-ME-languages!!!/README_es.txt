================================================================================
  ChainForge — Ejecución en Windows (nota del desarrollador)
================================================================================

Por qué Windows muestra una advertencia (SmartScreen)
--------------------------------------------------------------------------------
El programa no está firmado con un certificado de editor de pago. Windows lo
trata como un “archivo desconocido”, por eso puede aparecer la ventana azul de
“Windows protegió tu equipo” o “No se pudo verificar al editor”. Es NORMAL en
compilaciones sin firma y no significa automáticamente que sea un virus.

No hay código malicioso en esta compilación: es una aplicación de escritorio
habitual (Tauri). Si confías en el origen del archivo, puedes ejecutarla.

Cómo ejecutarla SIN desactivar por completo la protección de Windows
--------------------------------------------------------------------------------
1) Haz doble clic en app.exe.

2) Si aparece SmartScreen:
   • Pulsa “Más información” (More info).
   • Luego “Ejecutar de todas formas” (Run anyway).

Así solo permites ESTE archivo; no desactivas la protección del sistema.

Adicional (si el archivo está “bloqueado” tras descargarlo)
--------------------------------------------------------------------------------
1) Clic derecho en el exe → Propiedades.
2) Abajo, si aparece “Desbloquear”, márcalo → Aceptar.

No recomendado
--------------------------------------------------------------------------------
Desactivar SmartScreen o el Defender de forma permanente reduce la seguridad.
Basta con permitir una vez este programa, como se indica arriba.

Qué necesita el equipo
--------------------------------------------------------------------------------
• Windows 10 u 11 (64 bits).
• WebView2 suele estar instalado; si hay error al iniciar, instala
  “Microsoft Edge WebView2 Runtime” desde el sitio oficial de Microsoft.

================================================================================
