================================================================================
  ChainForge — Lancement sous Windows (note du développeur)
================================================================================

Pourquoi Windows affiche un avertissement (SmartScreen)
--------------------------------------------------------------------------------
Le programme n’est pas signé avec un certificat d’éditeur payant. Windows le
considère comme un « fichier inconnu », d’où la fenêtre bleue « Windows a
protégé votre PC » ou « Impossible de vérifier l’éditeur ». C’est NORMAL pour
des builds non signées et cela ne signifie pas automatiquement qu’il s’agit
d’un virus.

Il n’y a pas de code malveillant dans cette build — c’est une application
bureau classique (Tauri). Si vous faites confiance à la source, vous pouvez
l’exécuter.

Comment lancer SANS désactiver entièrement la protection Windows
--------------------------------------------------------------------------------
1) Double-cliquez sur app.exe.

2) Si SmartScreen s’affiche :
   • Cliquez sur « Plus d’infos » (More info).
   • Puis sur « Exécuter quand même » (Run anyway).

Vous n’autorisez que CE fichier, pas la désactivation globale de la protection.

En plus (si le fichier est « bloqué » après téléchargement)
--------------------------------------------------------------------------------
1) Clic droit sur l’exe → Propriétés.
2) En bas, si « Débloquer » est présent, cochez la case → OK.

Non recommandé
--------------------------------------------------------------------------------
Désactiver définitivement SmartScreen ou Windows Defender affaiblit la
sécurité du PC. Une autorisation unique pour ce programme suffit, comme ci-dessus.

Ce qu’il faut sur l’ordinateur
--------------------------------------------------------------------------------
• Windows 10 ou 11 (64 bits).
• WebView2 est en général déjà installé ; en cas d’erreur au lancement,
  installez « Microsoft Edge WebView2 Runtime » depuis le site officiel Microsoft.

================================================================================
