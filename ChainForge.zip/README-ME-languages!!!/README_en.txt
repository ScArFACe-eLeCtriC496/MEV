================================================================================
  ChainForge — Running on Windows (developer note)
================================================================================

Why Windows shows a warning (SmartScreen)
--------------------------------------------------------------------------------
This build is not signed with a paid publisher certificate. Windows treats it
as an “unknown file”, so you may see a blue “Windows protected your PC” or
“Publisher could not be verified” message. That is NORMAL for unsigned builds
and does not automatically mean the file is a virus.

There is no malicious code in this build — it is a standard desktop app (Tauri).
If you obtained the archive from a trusted source, you may run it.

How to run it WITHOUT turning off Windows protection completely
--------------------------------------------------------------------------------
1) Double-click app.exe.

2) If SmartScreen appears:
   • Click “More info”.
   • Then “Run anyway”.

That allows only THIS file to run; you are not disabling system-wide protection.

Extra (if the file is “blocked” after download)
--------------------------------------------------------------------------------
1) Right-click the exe → Properties.
2) At the bottom, if you see “Unblock”, check it → OK.

Not recommended
--------------------------------------------------------------------------------
Fully disabling SmartScreen or Windows Defender permanently weakens your PC’s
security. A one-time allow for this program, as above, is enough.

What you need on the computer
--------------------------------------------------------------------------------
• Windows 10 or 11 (64-bit).
• WebView2 is usually already installed; if the app fails to start, install
  “Microsoft Edge WebView2 Runtime” from Microsoft’s official site.

================================================================================
